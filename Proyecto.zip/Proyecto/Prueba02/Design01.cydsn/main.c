#include "project.h"

// =========================
//     Funciones Motores
// =========================

// Motor 1 (eje X)
void Motor1_Forward()
{
    Pin_M1_IN1_Write(1);
    Pin_M1_IN2_Write(0);
}

void Motor1_Backward()
{
    Pin_M1_IN1_Write(0);
    Pin_M1_IN2_Write(1);
}

void Motor1_Stop()
{
    Pin_M1_IN1_Write(0);
    Pin_M1_IN2_Write(0);
}

// Motor 2 (eje Y)
void Motor2_Forward()
{
    Pin_M2_IN1_Write(1);
    Pin_M2_IN2_Write(0);
}

void Motor2_Backward()
{
    Pin_M2_IN1_Write(0);
    Pin_M2_IN2_Write(1);
}

void Motor2_Stop()
{
    Pin_M2_IN1_Write(0);
    Pin_M2_IN2_Write(0);
}

// =========================
//     Servo SG90
// =========================
// 0°  → 1ms  (duty 5%)
// 90° → 1.5ms (duty 7.5%)
// 180° → 2ms (duty 10%)

void Servo_WriteAngle(float angle)
{
    // duty = 5% + (angle/180)*5%
    float duty = 5 + (angle / 180.0) * 5.0;
    uint16 compare = (uint16)((duty / 100.0) * 20000); // periodo 20 ms

    PWM_Servo_WriteCompare(compare);
}

void Lapiz_Arriba()
{
    Servo_WriteAngle(0);
}

void Lapiz_Abajo()
{
    Servo_WriteAngle(40);  // Ajusta según tu mecanismo
}

// =========================
//     Programa principal
// =========================

int main(void)
{
    CyGlobalIntEnable;

    PWM_M1_Start();
    PWM_M2_Start();
    PWM_Servo_Start();

    // Velocidad de motores
    PWM_M1_WriteCompare(180);   // Ajusta según fuerza
    PWM_M2_WriteCompare(180);

    // Preparación
    Lapiz_Arriba();
    CyDelay(1000);

    for(;;)
    {
        // =====================
        //     DIBUJAR CUADRADO
        // =====================

        Lapiz_Abajo();
        CyDelay(500);

        // LADO 1 (derecha)
        Motor1_Forward();
        CyDelay(800);
        Motor1_Stop();

        // LADO 2 (arriba)
        Motor2_Forward();
        CyDelay(800);
        Motor2_Stop();

        // LADO 3 (izquierda)
        Motor1_Backward();
        CyDelay(800);
        Motor1_Stop();

        // LADO 4 (abajo)
        Motor2_Backward();
        CyDelay(800);
        Motor2_Stop();

        Lapiz_Arriba();
        CyDelay(2000);
    }
}
