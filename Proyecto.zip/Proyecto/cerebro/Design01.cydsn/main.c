#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_1_Start();
    UART_2_Start();

   for(;;)
    {
        uint8 dato; 
        
        // 1. Revisar si UART_1 (ATmega) tiene algo
        if (UART_1_GetRxBufferSize() > 0) 
        {
            // 2. Leer el dato del ATmega
            dato = UART_1_GetByte();
            
            // 3. Escribir el dato hacia la PC (UART_2)
            UART_2_PutChar(dato);
            switch(dato)
        {
            case '1':
                LED01_Write(1);
                break;

            case '2':
                LED02_Write(1);
                break;

            case '3':
                LED01_Write(0);
                break;
            
            case '4':
                LED02_Write(0);
                break;
        }
        }
    }
}

/* [] END OF FILE */
